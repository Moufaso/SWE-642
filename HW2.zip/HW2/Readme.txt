HW2 Documentation
Saman Hosseini

. Navigation bar added
. Bootstrap implemented
. Added data field with average and max and implemented js functions to calculate
. Implement js function to use cookie to great user
. Implemented js function to validate form
. Created a zipcodes.json file using AI for a collection of DMV area zipcodes
. Used AJAX to populate city and state using the zipcode.json file
. Added a link to the HW2 site inside the homepage of HW1

HW1 – Homepage
. S3 URL: http://shossei-swe642.s3-website-us-east-1.amazonaws.com/HW1/Homepage/

HW2 - CS Department
. S3 URL: http://shossei-swe642-hw2.s3-website-us-east-1.amazonaws.com/